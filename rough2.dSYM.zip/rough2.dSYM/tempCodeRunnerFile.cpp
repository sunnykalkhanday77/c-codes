#include<iostream>
using namespace std;

int main(){
      int n=10;

      for (int i=1; i<=n;i++){
            int m=10;
            for(int i=1;i<=m; i++){
cout<<"*";
            }
      }
      return 0;

}
